# FS-EXP-6
This repo belongs to University.

# Experiment 6 FS Proofs

## Experiment 6.1
<img src="/Assests/1.png" alt="Experiment 1">

## Experiment 6.2
<img src="/Assests/2.png" alt="Experiment 2">

## Experiment 6.3
<img src="/Assests/3.png" alt="Experiment 3">
